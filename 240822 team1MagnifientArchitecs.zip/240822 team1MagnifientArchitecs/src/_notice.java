
public class _notice {
	// 8월 22일 팀 1 team1 Magnifient Architecs 가상 주식 투자 프로그램
//	브랜치
	
	/*
	 *  !중요! 자바 프로젝트에 mysql-connector-java-8.0.20 추가해서 사용해야 한다. 
	 */

//	release -> 배포용, 최대한 덜 사용
//	master -> 모든 브랜치 합병용
//	gosu -> 구예은
//	gohu -> 이재민
//	gokang -> 이강호
	
	// 8월 26일
//	좋은 아침입니다.
//	dbUtil 패키지에 DBUtil.java와 go_db.propertis 파일을 추가했으니 db 접속 가능합니다.
	
//	main 브랜치 삭제하고 배포용 release 브랜치 생성. master브랜치를 default 브랜치로 변경
	
//	테이블 컬럼 이름이 많이 바껴서 만들어 둔 sql 쿼리문 모두 수정 필요
	
	// 8월 27일
//	로그인 화면 완료(gosu)
//	gosu와 gokang이 UI나눠서 작업
//	gohu는 db연결해서 기능 구현 중
	
	// 8월 29일
//	어제 1차 배포했는데 피드백 없는듯?
}
