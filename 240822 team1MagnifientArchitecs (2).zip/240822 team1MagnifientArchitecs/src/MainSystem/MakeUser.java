package MainSystem;

import java.util.Scanner;

public class MakeUser {
	private String user_ID;
	private String user_PW;
	private int user_Money;
	private int user_Stock;
	private int user_Date;
	private int user_SaveData;


}
